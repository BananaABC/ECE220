#ifndef IO_H
#define IO_H

#define _CRT_SECURE_NO_WARNINGS

void initializeIO(char*, char*);
int readRecord(int*, char*, char*, char*, int*);
void writeRecord(int, char*);
void closeIO();
void compare(char*, char*);

#endif
