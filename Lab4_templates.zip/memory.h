#ifndef MEMORY_H
#define MEMORY_H

#define _CRT_SECURE_NO_WARNINGS

void* safe_malloc(size_t);
void safe_free(void*);

#endif
