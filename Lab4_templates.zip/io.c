#include<stdio.h>
#include<string.h>
#include "io.h"

static FILE* inputFile;
static FILE* outputFile;

// this function opens both files: input and output
void initializeIO(char* inputFileName, char* outputFileName) {

}  

// this function reads sinlge line from the input file
// and saves the values into the input arguments
// and returns how many records it reads (0 if there is no more records to read)
int readRecord(int* currentDay, char* name, char* action, char* type, int* amount) {

}

// this function writes into an output file
// based on the requested format
void writeRecord(int day, char* message) {

}

// this function closes the files
void closeIO() {

}


// this function is used to compare your output file
// with the expected output
void compare(char fileNameA[], char fileNameB[]) {
  FILE* fileA=fopen(fileNameA,"r");
  FILE* fileB=fopen(fileNameB,"r");
  int row=1;
  int col=1;
  for(;!feof(fileA) && !feof(fileB);) {
    char c1=fgetc(fileA);
    char c2=fgetc(fileB);
    if(c1!=c2) {
      break;
    }
    if(c1=='\n') {
      row++;
      col=1;
    }
    else {
      col++;
    }
  }
  if (feof(fileA) && feof(fileB)) {
    printf("{***} The two files match!\n");
  }
  else {
    printf("{###} Inconsistency at character %d of line %d.\n",col,row);
  }
  fclose(fileA);
  fclose(fileB);
}
