#ifndef MAIN_H
#define MAIN_H

#define _CRT_SECURE_NO_WARNINGS

#define MAX_ACCOUNTS 10
#define FINAL_DAY 365
#define INPUT_FILE "sampleInput.txt"
#define OUTPUT_FILE "sampleOutput.txt"
#define TEST_FILE "testOutput.txt"

#endif
